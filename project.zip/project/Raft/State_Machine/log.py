
class Log:
    def __init__(self, term, command):
        self.term = term
        self.command = command
