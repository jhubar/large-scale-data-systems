

# States const
FOLLOWER = 'follower'
LEADER = 'leader'
CANDIDATE = 'candidate'

# Request objects
VOTE_REQ = 'vote_request'
VOTE_ASW = 'vote_answer'
HEARTBEAT = 'heartbeat'